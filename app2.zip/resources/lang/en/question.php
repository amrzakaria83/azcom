<?php 

return [
    "add_more" => "Add more",
    "add_new" => "Add new",
    "edit" => "Edit",
    "name" => "Name",
    "questions" => "Questions",
    "question" => "Question",
    "photo" => "Photo",
    "title" => "Title",
    "view_attechment" => "View",
    "answer" => "Answer",
    "correct_answer" => "Correct answer",
    "remove" => "Delete",
    "level" => "level",
    "subject" => "subject",
    "search" => "Search",
    "choose" => "Choose ...",
    "close" => "Close",
    "save" => "Save",
    "action" => "Action",
    "filter" => "Search filter",
];