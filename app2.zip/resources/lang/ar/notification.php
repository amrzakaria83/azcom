<?php 

return [
    "add_new" => "اضف جديد",
    "edit" => "تعديل",
    "created_at" => "تاريخ الانشاء",
    "from_created_at" => "من تاريخ",
    "to_created_at" => "الى تاريخ",
    "name" => "الاسم",
    "title" => "العنوان",
    "student" => "الطالب",
    "search" => "البحث",
    "description" => "محتوى الصفحة",
    "choose" => "اختر ...",
    "close" => "الغاء",
    "save" => "حفظ",
    "action" => "الاجراء",
    "filter" => "فلتر البحث",
];