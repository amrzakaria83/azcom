<?php 

return [
    "add_new" => "اضف جديد",
    "edit" => "تعديل",
    "name" => "الاسم",
    "account_type" => "نوع الحساب",
    "phone" => "رقم الهاتف",
    "password" => "كلمة المرور",
    "least_6_letters" => "ما لا يقل عن 8 أحرف",
    "is_active" => "هل مفعل ؟ ",
    "active" => "مفعل",
    "notactive" => "غير مفعل",
    "choose" => "اختر ...",
    "close" => "الغاء",
    "save" => "حفظ",
    "action" => "الاجراء",
    "filter" => "فلتر البحث",
    "student_list" => "قائمة الطلاب",
    "Edit_account" => "تعديل حساب الدخول",
];