<?php 

return [
    "add_new" => "Add new",
    "edit" => "Edit",
    "created_at" => "Created date",
    "from_created_at" => "From date",
    "to_created_at" => "To date",
    "name" => "Name",
    "title" => "Title",
    "student" => "Student",
    "search" => "Search",
    "description" => "Description",
    "choose" => "Choose ...",
    "close" => "Close",
    "save" => "Save",
    "action" => "Action",
    "filter" => "Search filter",
];