<?php 

return [
    "add_new" => "Add new",
    "edit" => "Edit",
    "name" => "Name",
    "account_type" => "Account type",
    "phone" => "Phone",
    "password" => "Password",
    "least_6_letters" => "At least 8 letters",
    "is_active" => "Is active ?",
    "active" => "Active",
    "notactive" => "Not active",
    "choose" => "Choose ...",
    "close" => "Close",
    "save" => "Save",
    "action" => "Action",
    "filter" => "Search filter",
    "student_list" => "Students list",
    "Edit_account" => "Edit account to login",
];