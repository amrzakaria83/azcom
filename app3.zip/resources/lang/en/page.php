<?php 

return [
    "add_new" => "Add new",
    "edit" => "Edit",
    "photo" => "Photo",
    "photo_type" => "Allowed file types:",
    "name" => "Name",
    "title" => "Title",
    "subject" => "subject",
    "search" => "Search",
    "description" => "Description",
    "choose" => "Choose ...",
    "close" => "Close",
    "save" => "Save",
    "action" => "Action",
    "filter" => "Search filter",
];