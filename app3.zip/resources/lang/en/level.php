<?php 

return [
    "add_new" => "Add new",
    "edit" => "Edit",
    "name" => "Name",
    "title" => "Title",
    "subject" => "subject",
    "search" => "Search",
    "choose" => "Choose ...",
    "close" => "Close",
    "save" => "Save",
    "action" => "Action",
    "filter" => "Search filter",
];