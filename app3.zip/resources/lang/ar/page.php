<?php 

return [
    "add_new" => "اضف جديد",
    "edit" => "تعديل",
    "photo" => "صوره",
    "photo_type" => "أنواع الملفات المسموح بها:",
    "name" => "الاسم",
    "title" => "العنوان",
    "subject" => "الماده",
    "search" => "البحث",
    "description" => "محتوى الصفحة",
    "choose" => "اختر ...",
    "close" => "الغاء",
    "save" => "حفظ",
    "action" => "الاجراء",
    "filter" => "فلتر البحث",
];