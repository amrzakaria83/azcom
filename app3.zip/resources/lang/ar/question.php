<?php 

return [
    "add_more" => "اضف المزيد",
    "add_new" => "اضف جديد",
    "edit" => "تعديل",
    "name" => "الاسم",
    "questions" => "الاسئلة",
    "question" => "السؤال",
    "photo" => "الصورة",
    "title" => "العنوان",
    "view_attechment" => "شاهد المرفق",
    "answer" => "الاجابة",
    "correct_answer" => "الاجابه صحيحه",
    "remove" => "حذف",
    "level" => "المرحلة التعليمية",
    "subject" => "الماده",
    "search" => "البحث",
    "choose" => "اختر ...",
    "close" => "الغاء",
    "save" => "حفظ",
    "action" => "الاجراء",
    "filter" => "فلتر البحث",
];