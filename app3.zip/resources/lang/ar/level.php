<?php 

return [
    "add_new" => "اضف جديد",
    "edit" => "تعديل",
    "name" => "الاسم",
    "title" => "العنوان",
    "subject" => "الماده",
    "search" => "البحث",
    "choose" => "اختر ...",
    "close" => "الغاء",
    "save" => "حفظ",
    "action" => "الاجراء",
    "filter" => "فلتر البحث",
];