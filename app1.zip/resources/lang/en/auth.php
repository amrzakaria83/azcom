<?php 

return [
    "login" => "Sign In",
    "logout" => "Sign out",
    "login_btn" => "Sign In",
    "email" => "Email",
    "password" => "Password",
    "error_password" => "The password is incorrect!",
    "error_email" => "This account does not exist!",
    "error_is_active" => "This account is not activated!",
    "profile" => "Profile",
    "error_exist" => "This account exist",
    "not_login" => 'You must Sign In',
];